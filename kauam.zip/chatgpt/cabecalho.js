const botaoMenu = document.querySelector('.cabecalho__menu');
const navegacao = document.querySelector('.cabecalho__navegacao');
const botoesNavegacao = navegacao.querySelectorAll('button');
const telaPequena = window.matchMedia('(max-width: 767px)');

function definirMenu(aberto) {
    botaoMenu.setAttribute('aria-expanded', String(aberto));
    botaoMenu.setAttribute('aria-label', aberto ? 'Fechar menu' : 'Abrir menu');
}

botaoMenu.addEventListener('click', () => {
    definirMenu(botaoMenu.getAttribute('aria-expanded') !== 'true');
});

botoesNavegacao.forEach((botao) => {
    botao.addEventListener('click', () => {
        botoesNavegacao.forEach((item) => {
            item.setAttribute('aria-pressed', String(item === botao));
        });

        definirMenu(false);
        if (telaPequena.matches) botaoMenu.focus();
    });
});

document.addEventListener('keydown', (evento) => {
    if (evento.key === 'Escape' && botaoMenu.getAttribute('aria-expanded') === 'true') {
        definirMenu(false);
        botaoMenu.focus();
    }
});

telaPequena.addEventListener('change', () => definirMenu(false));
